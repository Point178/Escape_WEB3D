The files included in this archive are

	The obj itself:
	-book.obj
	-book.mtl

	UV maps:
	-binding.tga
	-cover.tga
	-pages.tga

	Texture files:
	-binding_diffuse.tga
	-cover_diffuse.tga
	-pages_diffuse.tga

You may use these for commercial or non-commercial work, no royalties required.  You may not redistribute or resell any of the files included in this archive, either separately or as part of some other package.

This was created by Pam Griffith
pamgriffith@gmail.com